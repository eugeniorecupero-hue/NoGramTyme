// Top‑level build file where you can add configuration options common to all sub‑projects/modules.
plugins {
    // These plugins are applied to the sub‑modules. The versions defined here are used
    // by the build system when evaluating the module build scripts.
    id("com.android.application") version "8.3.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.21" apply false
    id("org.jetbrains.kotlin.kapt") version "1.9.21" apply false
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

tasks.register("clean", Delete::class) {
    delete(rootProject.buildDir)
}