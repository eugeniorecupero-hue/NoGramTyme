# NoGram Time

**NoGram Time** è un’applicazione Android open source in Kotlin il cui scopo è limitare l’uso di Instagram (pacchetto `com.instagram.android`) in base a pianificazioni configurabili. Il progetto funziona interamente on‑device, senza backend remoto, e mette al centro privacy e affidabilità.

## Funzionalità principali

1. **Pianificazione** – l’utente può creare, modificare e cancellare regole che definiscono finestre orarie e giorni della settimana in cui Instagram deve essere bloccato. Le regole sono persistite localmente in Room.
2. **Blocco tramite AccessibilityService** – un `AccessibilityService` intercetta gli eventi `TYPE_WINDOW_STATE_CHANGED`【401119557551334†L1305-L1312】, legge il `packageName` dell’app in primo piano【248230294453495†L811-L823】 e, se corrisponde a Instagram e una regola è attiva, avvia un’overlay a schermo intero che impedisce l’interazione con l’app.
3. **Overlay Compose** – l’overlay è realizzato con Jetpack Compose e visualizza un messaggio personalizzabile e un pulsante “Esci” che riporta alla schermata Home.
4. **Affidabilità** – un servizio in primo piano mantiene l’app viva; un `BootReceiver` riavvia i servizi dopo il reboot; un `WorkManager` verifica periodicamente che accessibilità e (opzionalmente) VPN siano attivi; il codice considera Doze e App Standby mantenendo un notification channel a bassa priorità.
5. **Protezione impostazioni** – l’accesso alle impostazioni dell’app è protetto da un PIN (4–8 cifre) crittografato con `EncryptedSharedPreferences`. Il PIN è richiesto per aprire la schermata Impostazioni e può essere cambiato o rimosso.
6. **Resistenza alla disinstallazione** – l’app può essere registrata come *Device Administrator*; questo richiede che l’utente disattivi l’amministratore prima di disinstallare l’app. L’impossibilità totale di rimuovere l’app è consentita solo in contesti enterprise tramite *Device Owner*, che richiede provisioning all’avvio/reset e non può essere attivata da un’app installata dall’utente【774723391814998†L490-L495】.
7. **Blocco rete (opzionale)** – un modulo `VpnService` crea un’interfaccia VPN fittizia e inserisce Instagram nella lista delle app proibite (`addDisallowedApplication`)【169523580676260†L869-L872】. Quando abilitato, il traffico di rete di Instagram bypassa la VPN e viene bloccato dal sistema. È disattivabile dall’utente nelle impostazioni.

## Struttura progetto

```
NoGramTime/
 ├── app/
 │   ├── build.gradle.kts       – configurazione modulo Android (Compose, Room, WorkManager, Security).
 │   └── src/main/
 │       ├── AndroidManifest.xml – dichiarazioni di permessi, servizi e receiver.
 │       ├── java/com/example/nogramtime/
 │       │   ├── MainActivity.kt
 │       │   ├── OverlayActivity.kt
 │       │   ├── admin/
 │       │   │   └── AdminReceiver.kt
 │       │   ├── boot/
 │       │   │   └── BootReceiver.kt
 │       │   ├── data/
 │       │   │   ├── AppDatabase.kt, BlockRule.kt, BlockRuleDao.kt, Converters.kt, ScheduleRepository.kt
 │       │   │   └── SettingsManager.kt – preferenze sicure (sospensione blocco, VPN).
 │       │   ├── pin/
 │       │   │   ├── PinManager.kt – gestisce PIN crittografato.
 │       │   │   └── PinViewModel.kt
 │       │   ├── service/
 │       │   │   ├── BlockAccessibilityService.kt
 │       │   │   ├── ForegroundMonitorService.kt
 │       │   │   └── BlockingVpnService.kt (facoltativo)
 │       │   ├── ui/
 │       │   │   ├── HomeScreen.kt – stato attuale e prossimo blocco.
 │       │   │   ├── ScheduleScreen.kt – CRUD regole.
 │       │   │   ├── ScheduleViewModel.kt
 │       │   │   └── SettingsScreen.kt – PIN e preferenze.
 │       │   └── work/
 │       │       └── ResilienceWorker.kt
 │       ├── res/
 │       │   ├── values/strings.xml – testi in italiano.
 │       │   ├── xml/accessibility_service_config.xml – configurazione service.
 │       │   └── xml/device_admin_receiver.xml – criteri admin.
 │       └── … (icone, temi, colori)
 ├── build.gradle.kts           – impostazioni Gradle del progetto.
 └── settings.gradle.kts        – include il modulo `:app`.
```

## Build e installazione

Per compilare l’app è necessaria un’installazione recente di **Android Studio** (Electric Eel o superiore) e il **JDK 17**. La minSdk è 26 e la targetSdk è 34.

1. Clonare il repository e aprire il progetto `NoGramTime` in Android Studio.
2. Attendere il sync Gradle e assicurarsi che il dispositivo o l’emulatore abbia Android 8.0 (API 26) o superiore.
3. Generare l’APK debug con:

   ```bash
   ./gradlew :app:assembleDebug
   ```

   L’APK risultante si trova in `app/build/outputs/apk/debug/app-debug.apk`.

4. Installare l’APK su dispositivo via ADB:

   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

In alternativa è possibile utilizzare **Build > Build Bundle(s) / APK(s)** da Android Studio.

## Attivazione dei permessi

Per funzionare correttamente, NoGram Time richiede i seguenti permessi e servizi:

1. **Accessibilità** – aprire **Impostazioni > Accessibilità** e abilitare “NoGram Time” nella sezione Servizi installati. Questa autorizzazione consente al servizio di monitorare la finestra attiva e intercettare l’apertura di Instagram.
2. **Overlay (Draw over other apps)** – alla prima esecuzione Android chiederà di consentire a NoGram Time di disegnare sopra le altre app. Questo permesso è necessario per mostrare l’overlay di blocco a schermo intero.
3. **Amministratore dispositivo (facoltativo ma consigliato)** – nella schermata Impostazioni è presente il pulsante “Amministratore dispositivo”. Toccando **Attiva** si aprirà la schermata di sistema per abilitare l’app come amministratore. Finché l’amministratore è attivo non sarà possibile disinstallare l’app senza prima disattivarlo.
4. **VPN (facoltativa)** – nella schermata Impostazioni è disponibile l’opzione “VPN Instagram”. Attivandola viene avviato un `VpnService` che nega l’accesso in rete ad Instagram aggiungendo l’app alla lista delle applicazioni proibite【169523580676260†L869-L872】. L’utente può disabilitare la VPN in qualsiasi momento.

## Uso dell’app

1. **Home** – mostra se Instagram è attualmente bloccato e quando avverrà il prossimo blocco. Da qui si può accedere alla gestione delle regole.
2. **Pianificazione** – permette di creare e modificare le regole di blocco. Ogni regola specifica i giorni della settimana e l’intervallo orario in cui Instagram deve essere bloccato. Le regole possono anche attraversare la mezzanotte.
3. **Impostazioni** – protette da PIN. Qui è possibile:
   - Impostare o cambiare il PIN.
   - Sospendere temporaneamente il blocco (utile per pause occasionali).
   - Attivare/disattivare la VPN di blocco rete.
   - Gestire permessi overlay e accessibilità.
   - Attivare/disattivare l’amministratore dispositivo.

### Istruzioni ADB passo per passo

Su un dispositivo con ADB abilitato è possibile configurare l’app anche da riga di comando:

```bash
# Installazione APK
adb install -r path/to/app-debug.apk

# Avvio dell’app (facoltativo)
adb shell monkey -p com.example.nogramtime -c android.intent.category.LAUNCHER 1

# Apertura schermata Accessibility nelle impostazioni (per abilitare il service)
adb shell am start -a android.settings.ACCESSIBILITY_SETTINGS

# Apertura schermata overlay (per concedere draw over other apps)
adb shell am start -a android.settings.action.MANAGE_OVERLAY_PERMISSION -d "package:com.example.nogramtime"

# Apertura schermata amministratore dispositivo
adb shell am start -a android.app.action.ADD_DEVICE_ADMIN -e android.app.extra.DEVICE_ADMIN com.example.nogramtime/.admin.AdminReceiver
```

## Limitazioni e note etiche

* **Disinstallazione** – in ambito consumer Android non consente di rendere un’app veramente inamovibile. L’attivazione come Device Administrator impedisce la rimozione finché non viene disattivato manualmente, ma l’utente è sempre libero di farlo. L’impossibilità assoluta di disinstallare richiede che l’app sia configurata come *Device Owner* prima o durante il provisioning del dispositivo (ambiente enterprise/MDM)【774723391814998†L490-L495】.
* **VPN** – il modulo VPN utilizza `addDisallowedApplication("com.instagram.android")`【169523580676260†L869-L872】 per negare il traffico a Instagram. Altre app o domini non sono instradati attraverso la VPN, quindi il dispositivo mantiene la connettività normale. Alcuni dispositivi e versioni di Android potrebbero gestire in modo diverso le app disallowed; testare su hardware reale.
* **Privacy** – l’app non invia nessun dato a server esterni né integra SDK di terze parti. Tutti i dati (regole, preferenze, PIN) rimangono localmente sul dispositivo.
* **Etica** – questo progetto è pensato come strumento per il *digital wellbeing* personale. È scoraggiato l’uso per controllare o limitare l’accesso ai servizi di altre persone senza il loro consenso. Inoltre, non implementa tecniche per aggirare le policy di sicurezza di Android né consente di nascondere la propria presenza.

## Script di build

Di seguito uno script opzionale (`build_apk.sh`) che può essere utilizzato in ambienti Unix per compilare rapidamente l’APK di release:

```bash
#!/bin/bash
set -e
./gradlew clean :app:assembleRelease
echo "APK pronto in app/build/outputs/apk/release/app-release.apk"
```

Rendere lo script eseguibile con `chmod +x build_apk.sh` e lanciarlo dalla root del progetto.

## Piano B / prototipo alternativo

Se non è possibile utilizzare Android Studio o ADB, è possibile realizzare un prototipo leggero utilizzando FlutterFlow o Kodular:

* **FlutterFlow** – creare un’app Flutter con tre schermate (Home, Pianificazione, Impostazioni). Utilizzare il database locale per memorizzare le regole; simulare l’overlay con una pagina modale che appare quando l’orario corrisponde a una regola attiva. La logica di accessibilità/VPN/device admin dovrà essere implementata nativamente in seguito, attraverso un modulo Android (Flutter “platform channel”).
* **Kodular** – configurare un progetto con un timer che verifica l’ora corrente e confronta con le finestre definite dall’utente, disabilitando un pulsante “Apri Instagram” durante le finestre bloccate. Questa soluzione non può impedire l’apertura di Instagram a livello di sistema ma dimostra la logica di pianificazione.

Entrambi i percorsi consentono di valutare l’interfaccia utente e la gestione locale dei dati in attesa dell’integrazione nativa completa.